export default {
  version_check: "https://raw.githubusercontent.com/JustKemForFun/ZaloDataExtractor/main/manifest.json",
  source_code: "https://github.com/JustKemForFun/ZaloDataExtractor",
  fallbackVersion: "1.1.0"
};
