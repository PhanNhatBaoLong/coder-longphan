import requests
from zlapi.models import Message
import ffmpeg
import json
import io
import os

des = {
    'version': "1.1.0",
    'credits': "Vũ Xuân Kiên",
    'description': "Tải video từ TikTok, YouTube, Facebook, CapCut và Douyin và gửi về nhóm chat",
    'power': "Thành viên"
}

def get_video_info(video_url):
    try:
        probe = ffmpeg.probe(video_url)
        video_stream = next((stream for stream in probe['streams'] if stream['codec_type'] == 'video'), None)
        if video_stream:
            duration = float(video_stream['duration']) * 1000
            width = int(video_stream['width'])
            height = int(video_stream['height'])
            return duration, width, height
        else:
            raise Exception("Không tìm thấy luồng video trong URL")
    except Exception as e:
        raise Exception(f"Lỗi khi lấy thông tin video: {str(e)}")

def upload_to_imgur(buffered):
    api_url = "https://api.imgur.com/3/image"
    headers = {
        "Authorization": f"Client-ID 85a847235508ec9"
    }

    try:
        response = requests.post(
            api_url,
            headers=headers,
            files={'image': buffered}
        )

        if response.status_code == 200:
            result = response.json()
            return result.get('data', {}).get('link')
        else:
            return None
    except Exception as e:
        return None

def handle_video_download(message, message_object, thread_id, thread_type, author_id, client):
    content = message.strip().split()
    if len(content) < 2:
        client.replyMessage(Message(text="Vui lòng nhập một đường link hợp lệ."), message_object, thread_id, thread_type, ttl=60000)
        return
    
    video_link = content[1].strip()
    send_audio = False
    if len(content) > 2 and content[2].lower() == "audio":
        send_audio = True

    if not video_link.startswith("https://"):
        client.replyMessage(Message(text="Vui lòng nhập một đường link hợp lệ (bắt đầu bằng https://)."), message_object, thread_id, thread_type, ttl=60000)
        return
    
    api_map = {
        "https://vt.tiktok.com/": "tiktok",
        "https://www.tiktok.com/": "tiktok",
        "https://www.youtube.com/": "youtube",
        "https://youtu.be/": "youtube",
        "https://www.facebook.com/": "fb",
        "https://www.capcut.com/": "capcut",
        "https://v.douyin.com/": "douyin"
    }
    
    for prefix, api_type in api_map.items():
        if video_link.startswith(prefix):
            if api_type == "tiktok":
                api_url = f'https://subhatde.id.vn/{api_type}/downloadvideo?url={video_link}'
            elif api_type == "youtube":
                 api_url = f'https://subhatde.id.vn/{api_type}/download?url={video_link}'
            elif api_type == "douyin":
                 api_url = f'https://subhatde.id.vn/tiktok/douyindl?url={video_link}'
            else:
                api_url = f'https://subhatde.id.vn/{api_type}/download?url={video_link}'
            try:
                response = requests.get(api_url)
                response.raise_for_status()
                data = response.json()
                
                video_url = None
                title = None
                thumbnail_url = None
                duration = None
                
                if api_type == "tiktok":
                    if 'data' not in data or 'play' not in data['data']:
                        raise ValueError("Không thể lấy video từ TikTok")
                    video_url = data['data']['play']
                    title = data['data']['title']
                    view = data['data']['play_count']
                    like = data['data']['digg_count']
                    down = int(data['data']['download_count'])
                    cmt = data['data']['comment_count']
                    thumbnail_url = data['data']['cover']
                    share = data['data']['share_count']
                    user_info = client.fetchUserInfo(author_id)
                    user_name = user_info.changed_profiles[author_id].zaloName
                    video_info = (
                        f"[ {user_name} ]\n\n"
                        f"• 🎬 Nền Tảng: TikTok\n"
                        f"• 💻 Title: {title}\n"
                        f"• 📊 View: {view}\n"
                        f"• ❤ Like: {like}\n"
                        f"• 💾 Lượt Tải: {down}\n"
                        f"• 💬 Lượt Bình Luận: {cmt}\n"
                        f"• 🧭 Lượt Chia Sẻ: {share}"
                    )
                    messagesend = Message(text=video_info)

                elif api_type == "youtube":
                    if 'videoUrl' not in data:
                        raise ValueError(f"Không thể lấy link video từ API cho {video_link}.")
                    video_url = data['videoUrl']
                    title = data.get('title', 'Không có tiêu đề')
                    duration = data.get('duration', '00:00:00')
                    video_id = data.get('id')
                    thumbnail_url = f"https://i.ytimg.com/vi/{video_id}/hqdefault.jpg"
                    user_info = client.fetchUserInfo(author_id)
                    user_name = user_info.changed_profiles[author_id].zaloName
                    messagesend = Message(text=f"[ {user_name} ]\n\n• 🎬 Nền Tảng: Youtube\n• 💻 Tiêu đề: {title}")
                    if duration:
                        parts = list(map(int,duration.split(':')))
                        total_seconds = parts[0] * 3600 + parts[1] * 60 + parts[2]
                    else:
                        total_seconds=0
                    duration=total_seconds
                elif api_type == "fb":
                    if 'url' not in data or 'title' not in data or 'thumbnail' not in data or 'medias' not in data:
                        raise ValueError(f"Không thể lấy link video từ API cho {video_link}.")
                    video_url = data['medias'][0]['url']
                    title = data['title']
                    thumbnail_url = data['thumbnail']
                    duration = int(data['duration'])
                    user_info = client.fetchUserInfo(author_id)
                    user_name = user_info.changed_profiles[author_id].zaloName
                    messagesend = Message(text=f"[ {user_name} ]\n\n• 🎬 Nền Tảng: Facebook\n• 💻 Title: {title}")

                elif api_type == "capcut":
                    if 'video_url' not in data:
                        raise ValueError(f"Không thể lấy video từ API cho {video_link}.")
                    video_url = data['video_url']
                    title = data.get('title', 'Không có tiêu đề')
                    thumbnail_url = 'https://f54-zpg-r.zdn.vn/jpg/1593082208972721683/63c52b8ec1697b372278.jpg'
                    duration = int(data.get('duration', 0))
                    user_info = client.fetchUserInfo(author_id)
                    user_name = user_info.changed_profiles[author_id].zaloName
                    messagesend = Message(text=f"[ {user_name} ]\n\n• 🎬 Nền Tảng: Capcut\n• 💻 Title: {title}")
                
                elif api_type == "douyin":
                    if 'attachments' not in data or not data['attachments']:
                        raise ValueError(f"Không thể lấy video từ API Douyin cho {video_link}.")
                    video_url = data['attachments'][0]['url']
                    title = data.get('caption', 'Không có tiêu đề')
                    thumbnail_url = None
                    user_info = client.fetchUserInfo(author_id)
                    user_name = user_info.changed_profiles[author_id].zaloName
                    messagesend = Message(text=f"[ {user_name} ]\n\n• 🎬 Nền Tảng: Douyin\n• 💻 Title: {title}")

                if send_audio:
                    if video_url:
                        try:
                            if api_type == "youtube" and "audioUrl" in data:
                                client.sendRemoteVoice(data['audioUrl'], thread_id, thread_type, fileSize=100000)
                            else:
                                client.sendRemoteVoice(video_url, thread_id, thread_type, fileSize=100000)
                        except Exception as e:
                            client.replyMessage(Message(text=f"Lỗi khi gửi audio: {str(e)}"), message_object, thread_id, thread_type, ttl=60000)
                        return
                    else:
                        client.replyMessage(Message(text="Không thể lấy được link video để gửi audio."), message_object, thread_id, thread_type, ttl=60000)
                        return

                if video_url:
                    try:
                        response = requests.get(video_url, stream=True)
                        response.raise_for_status()

                        buffered = io.BytesIO()
                        for chunk in response.iter_content(chunk_size=8192):
                            buffered.write(chunk)
                        buffered.seek(0)

                        imgur_url = upload_to_imgur(buffered.getvalue())

                        if imgur_url:
                            video_info = get_video_info(video_url)
                            if video_info:
                                video_duration, video_width, video_height = video_info
                            else:
                                video_duration, video_width, video_height = duration, 1200, 1600

                            client.sendRemoteVideo(
                                imgur_url,
                                thumbnail_url,
                                duration=video_duration,
                                message=messagesend,
                                thread_id=thread_id,
                                thread_type=thread_type,
                                ttl=86400000,
                                width=video_width,
                                height=video_height
                            )
                        else:
                            client.replyMessage(Message(text="Không thể upload video lên Imgur."), message_object, thread_id, thread_type, ttl=60000)

                    except Exception as e:
                        client.replyMessage(Message(text=f"Lỗi khi lấy thông tin video: {str(e)}"), message_object, thread_id, thread_type, ttl=60000)
                        return
                else:
                    client.replyMessage(Message(text="Không thể lấy được link video."), message_object, thread_id, thread_type, ttl=60000)
                
                return

            except requests.exceptions.RequestException as e:
                client.replyMessage(Message(text=f"Đã xảy ra lỗi khi gọi API: {str(e)}"), message_object, thread_id, thread_type, ttl=60000)
                return
            except ValueError as e:
                client.replyMessage(Message(text=str(e)), message_object, thread_id, thread_type, ttl=60000)
                return 
            except Exception as e:
                client.replyMessage(Message(text=f"Đã xảy ra lỗi không xác định: {str(e)}"), message_object, thread_id, thread_type, ttl=60000)
                return

def ft_vxkiue():
    return {
        'download': handle_video_download
    }