import json

def read_setting_value(key):
    try:
        with open('seting.json', 'r') as f:
            settings = json.load(f)
        return settings.get(key)
    except (FileNotFoundError, json.JSONDecodeError):
        print("Lỗi: Không thể load hoặc đọc file seting.json.  Sử dụng giá trị mặc định.")
        return None

def read_prefix():
    return read_setting_value('prefix')

def read_admin():
    return read_setting_value('admin')

IMEI = "e0257a25-5373-407d-8a1a-d715d4309d1e-b78b4e2d6c0a362c418b145fe44ed73f"
SESSION_COOKIES = {"_ga":"GA1.2.1829037959.1731307383","__zi":"3000.SSZzejyD6zOgdh2mtnLQWYQN_RAG01ICFjIXe9fEM8WydEkicavUXdAOxAdNJ5c3SfZjgpSn.1","__zi-legacy":"3000.SSZzejyD6zOgdh2mtnLQWYQN_RAG01ICFjIXe9fEM8WydEkicavUXdAOxAdNJ5c3SfZjgpSn.1","ozi":"2000.SSZzejyD6zOgdh2mtnLQWYQN_RAG01ICFjMXe9fFM8yxc-oadaLUW3sHfwsUHHE2EfIdhPz75O0.1","_zlang":"vn","_gid":"GA1.2.2048590660.1737191415","zpsid":"4O5M.425682506.24.9yR_9mHrMJzE4mOc27LPFt46AmisG6y7Da1f2Nzlwgqtcm6Y1NKfj6DrMJy","zpw_sek":"KrgV.425682506.a0.wHEm1yXrbIE24yewwNML8xDNy4ZgJxTvZq6XOle_lXQn5zzq-1FmS-Cprq6lIAW1jGwFa5f6UtjLT9HJGnAL8m","app.event.zalo.me":"8544154555473905947","_gat":"1"}

API_KEY = 'api_key'
SECRET_KEY = 'secret_key'
PREFIX = read_prefix() or "."
ADMIN = read_admin()
if ADMIN is None:
    ADMIN = []
elif not isinstance(ADMIN, list):
    ADMIN = [ADMIN]